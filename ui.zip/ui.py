from openai import OpenAI
import streamlit as st

st.title("ChatGPT-like clone")

client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])

if "openai_model" not in st.session_state:
    # st.session_state["openai_model"] = "gpt-3.5-turbo"
    st.session_state["openai_model"] = "gpt-4-32k"

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if not st.session_state.messages:  # Check if messages list is empty
    st.session_state.messages.append({"role": "system", "content": "Welcome to the chat!"})  # Add a welcome message

if prompt := st.chat_input("What is up?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

# Use st.form to add the file upload button
with st.form(key="file_upload_form"):
    uploaded_file = st.file_uploader("Upload a file", type=["txt", "pdf", "docx"])
    submit_button = st.form_submit_button(label="Submit")

if uploaded_file is not None:
    # Process the uploaded file, e.g., extract text
    file_contents = uploaded_file.read()
    st.write(f"Uploaded file contents: {file_contents}")

with st.chat_message("assistant"):
    message_placeholder = st.empty()
    full_response = ""
    for response in client.chat.completions.create(
        model=st.session_state["openai_model"],
        messages=[
            {"role": m["role"], "content": m["content"]}
            for m in st.session_state.messages
        ],
        stream=True,
    ):
        full_response += (response.choices[0].delta.content or "")
        message_placeholder.markdown(full_response + "▌")
    message_placeholder.markdown(full_response)
st.session_state.messages.append({"role": "assistant", "content": full_response})
